const encoder = new TextEncoder();
function b64url(bytes){return btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')}
async function sign(value,secret){const key=await crypto.subtle.importKey('raw',encoder.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);return b64url(await crypto.subtle.sign('HMAC',key,encoder.encode(value)))}
export async function onRequestPost({request,env}) {
  if(!env.ADMIN_USERNAME||!env.ADMIN_PASSWORD||!env.SESSION_SECRET)return Response.json({error:"Admin secrets are not configured."},{status:503});
  let body;try{body=await request.json()}catch{return Response.json({error:"Invalid request."},{status:400})}
  if(body.username!==env.ADMIN_USERNAME||body.password!==env.ADMIN_PASSWORD)return Response.json({error:"Incorrect username or password."},{status:401});
  const now=Math.floor(Date.now()/1000),payload=b64url(encoder.encode(JSON.stringify({sub:env.ADMIN_USERNAME,iat:now,exp:now+60*60*8})));
  const token=payload+"."+await sign(payload,env.SESSION_SECRET);
  return Response.json({ok:true},{headers:{"Set-Cookie":`admin_session=${token}; HttpOnly; Secure; SameSite=Strict; Path=/api/admin; Max-Age=28800`,"Cache-Control":"no-store"}});
}
